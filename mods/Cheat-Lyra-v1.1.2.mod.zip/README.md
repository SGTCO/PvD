## DoL-Lyra-Cheat

### FEATS

- Enable cheats by default
- Remove feats lock
- Enable Kotodama