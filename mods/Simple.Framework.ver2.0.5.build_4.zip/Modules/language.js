/* eslint-disable no-var */
/* eslint-disable max-len */
const Lang = (() => {
    'use strict';

    const _data = {
        NPCNames : {
            Avery          : { EN : 'Avery',        CN : '艾弗里' },
            Bailey         : { EN : 'Bailey',       CN : '貝利' },
            Briar          : { EN : 'Briar',        CN : '布萊爾' },
            Charlie        : { EN : 'Charlie',      CN : '查理' },
            Darryl         : { EN : 'Darryl',       CN : '達里爾' },
            Doren          : { EN : 'Doren',        CN : '多倫' },
            Eden           : { EN : 'Eden',         CN : '伊甸' },
            Gwylan         : { EN : 'Gwylan',       CN : '格威嵐' },
            Harper         : { EN : 'Harper',       CN : '哈珀' },
            Jordan         : { EN : 'Jordan',       CN : '約旦' },
            Kylar          : { EN : 'Kylar',        CN : '凱拉爾' },
            Landry         : { EN : 'Landry',       CN : '蘭德里' },
            Leighton       : { EN : 'Leighton',     CN : '禮頓' },
            Mason          : { EN : 'Mason',        CN : '梅森' },
            Morgan         : { EN : 'Morgan',       CN : '摩根' },
            River          : { EN : 'River',        CN : '瑞沃' },
            Robin          : { EN : 'Robin',        CN : '羅賓' },
            Sam            : { EN : 'Sam',          CN : '薩姆' },
            Sirris         : { EN : 'Sirris',       CN : '西里斯' },
            Whitney        : { EN : 'Whitney',      CN : '惠特尼' },
            Winter         : { EN : 'Winter',       CN : '溫特' },
            'Black Wolf'   : { EN : 'Black Wolf',   CN : '黑狼' },
            Niki           : { EN : 'Niki',         CN : '尼奇' },
            Quinn          : { EN : 'Quinn',        CN : '奎恩' },
            Remy           : { EN : 'Remy',         CN : '雷米' },
            Alex           : { EN : 'Alex',         CN : '艾利克斯' },
            'Great Hawk'   : { EN : 'Great Hawk',   CN : '巨鷹' },
            Wren           : { EN : 'Wren',         CN : '倫恩' },
            Sydney         : { EN : 'Sydney',       CN : '悉尼' },
            'Ivory Wraith' : { EN : 'Ivory Wraith', CN : '象牙怨靈' },
            Zephyr         : { EN : 'Zephyr',       CN : '澤菲爾' }
        },
        common : {
            next         : { EN : 'Next', CN : '繼續' },
            leave        : { EN : 'Leave', CN : '離開' },
            back         : { EN : 'Back', CN : '返回' },
            items        : { EN : 'Items', CN : '物品' },
            ITEMS        : { EN : 'ITEMS', CN : '物品' },
            unequip      : { EN : 'Unequip', CN : '卸下' },
            equip        : { EN : 'Equip', CN : '裝備' },
            move         : { EN : 'Move', CN : '移動' },
            drop         : { EN : 'Drop', CN : '丟棄' },
            willpower    : { EN : 'Willpower', CN : '意志' },
            alcohol      : { EN : 'Alcohol', CN : '酒精' },
            hallucinogen : { EN : 'Hallucinogen', CN : '幻覺' },
            hunger       : { EN : 'Hunger', CN : '飢餓' },
            health       : { EN : 'Health', CN : '健康' },
            storage      : { EN : 'Storage', CN : '庫存' },
            mechanic     : { EN : 'Mechanic', CN : '機械' },
            chemical     : { EN : 'Chemical', CN : '化學' },
            cooking      : { EN : 'Cooking', CN : '烹飪' },
            wakeup       : { EN : 'Wake up', CN : '醒來' },
            loiter       : { EN : 'Loiter', CN : '閒逛' },
            take         : { EN : 'Take', CN : '取出' },
            takehalf     : { EN : 'Take half', CN : '取出一半' },
            clearall     : { EN : 'Clear', CN : '清空' },

            boy  : { EN : 'boy', CN : '男孩' },
            girl : { EN : 'girl', CN : '女孩' },

            him     : { EN : 'him', CN : '他' },
            his     : { EN : 'his', CN : '他的' },
            he      : { EN : 'he', CN : '他' },
            himself : { EN : 'himself', CN : '他自己' },
            she     : { EN : 'she', CN : '她' },
            her     : { EN : 'her', CN : '她的' },
            herself : { EN : 'herself', CN : '她自己' }
        }
    };

    function _CheckLanguage() {
        const lancheck = setup.language || navigator.language || navigator.userLanguage;
        let lan = 'EN';
        if (lancheck.includes('zh')) {
            lan = 'CN';
        }

        if (V && V.iModConfigs?.language) {
            lan = V.iModConfigs.language;
        }

        return lan;
    }

    function _findAvailableLanguage(obj) {
        const language = _CheckLanguage();
        if (obj[language] == undefined) {
            return Object.keys(obj)[0];
        }

        return language;
    }
    /**
     * The function to switch language string based on setup variable.
     *
     * @param {...(string|Object|string[])} lan - A list of language strings.
     *   It could be a single object with 'EN' and/or 'CN' properties (type 1),
     *   or two strings (EN and CN) (type 2),
     *   or an array containing these two strings (type 3).
     * @returns {string} - The selected string based on the 'setup.language' value. If 'setup.language' is 'CN', it returns CN value; otherwise, it returns EN value. If CN or EN are not defined, it will try to return the first defined one.
     *
     * @example <caption>Type 1: object as input</caption>
     *   lanSwitch({ EN: 'Hello', CN: '你好'}); // returns 'Hello' if setup.language is not 'CN'
     * @example <caption>Type 2: separate strings as input</caption>
     *   lanSwitch('Hello', '你好'); // returns 'Hello' if setup.language is not 'CN'
     * @example <caption>Type 3: array of strings as input</caption>
     *   lanSwitch(['Hello', '你好']); // returns 'Hello' if setup.language is not 'CN'
     */
    function _languageSwitch(...lanObj) {
        let lan;

        if (isObject(lanObj[0])) {
            lan = _findAvailableLanguage(lanObj[0]);
            return lanObj[0][lan];
        }

        const obj = {
            EN : lanObj[0],
            CN : lanObj[1]
        };

        if (Array.isArray(lanObj[0])) {
            obj.EN = lanObj[0][0];
            obj.CN = lanObj[0][1];
        }

        lan = _findAvailableLanguage(obj);

        return obj[lan];
    }

    function _getLang(keyPath) {
        if (keyPath.includes('.')) {
            const langObj = getPath(_data, keyPath);
            if (langObj == undefined) {
                return `[Language Error] Missing key: ${keyPath}`;
            }
            
            return _languageSwitch(langObj);
        }

        if (_data[keyPath] == undefined) {
            return `[Language Error] Missing key: ${keyPath}`;
        }

        return _languageSwitch(_data[keyPath]);
    }

    function _setLang(obj, keyPath) {
        if (keyPath) {
            const landata = getPath(_data, keyPath);
            for (const key in obj) {
                landata[key] = obj[key];
            }

            return landata;
        }

        for (const key in obj) {
            if (_data[key] == undefined) {
                _data[key] = obj[key];
            }
        }

        return _data;
    }

    Object.defineProperties(window, {
        lanSwitch : {
            value : _languageSwitch
        },

        getLan : {
            value : _getLang
        }
    });
    
    return Object.seal({
        get data() {
            return _data;
        },

        set : _setLang,
        get : _getLang,
        
        check  : _CheckLanguage,
        switch : _languageSwitch
    });
})();


const printer = (() => {
    'use strict';

    function _templet(string, ...args) {
        // check if string is valid
        const isValid = function (str) {
            if (String(str) == '[object Object]' && (str.EN || str.CN)) return true;
            return typeof str === 'string' || Array.isArray(str) || typeof str === 'number';
        };
    
        const isLan = function (str) {
            return String(str) == '[object Object]' || Array.isArray(str);
        };
    
        if (!isValid(string)) return;
    
        if (isLan(string)) {
            string = lanSwitch(string);
        }
    
        for (let i = 0; i < args.length; i++) {
            let txt = args[i];
    
            if (!isValid(txt)) continue;
    
            if (isLan(txt)) {
                txt = Lang.switch(txt);
            }
    
            string = string.replaceAll(`{${i}}`, txt);
        }
        return string;
    }

    function toLower(str) {
        if (String(str) == '[object Object]' && (str.EN || str.CN)) {
            str.EN = str.EN.toLowerCase();
            return str;
        }
        
        if (Array.isArray(str)) {
            str[0] = str[0].toLowerCase();
            return str;
        }
    
        return str.toLowerCase();
    }

    function toUpper(str) {
        if (String(str) == '[object Object]' && (str.EN || str.CN)) {
            str.EN = str.EN.toUpperFirst();
            return str;
        }
        
        if (Array.isArray(str)) {
            str[0] = str[0].toUpperFirst();
            return str;
        }
    
        return str.toUpperFirst();
    }

    function toFull(str) {
        if (String(str) == '[object Object]' && (str.EN || str.CN)) {
            str.EN = str.EN.toUpperCase();
            return str;
        }
        
        if (Array.isArray(str)) {
            str[0] = str[0].toUpperCase();
            return str;
        }
    
        return str.toUpperCase();
    }

    function toCamel(str) {
        if (String(str) == '[object Object]' && (str.EN || str.CN)) {
            str.EN = str.EN.toCamelCase();
            return str;
        }
        
        if (Array.isArray(str)) {
            str[0] = str[0].toCamelCase();
            return str;
        }
    
        return str.toCamelCase();
    }

    return Object.seal({
        templet : _templet,
        toLower,
        toUpper,
        toFull,
        toCamel
    });
})();

// for shortcut
Object.defineProperties(window, {
    P : { get : () => printer },
    L : { get : () => Lang }
});
